export IMAGE_FAMILY="tf2-latest-cpu"
export ZONE="europe-west6-a"
export INSTANCE_NAME="amd-instance"
export INSTANCE_TYPE="n1-standard-1"

gcloud compute instances create $INSTANCE_NAME \
        --zone=$ZONE \
        --image-family=$IMAGE_FAMILY \
        --image-project=deeplearning-platform-release \
        --maintenance-policy=TERMINATE \
        --machine-type=$INSTANCE_TYPE \
        --boot-disk-size=200GB \
        --preemptible

